package com.herokuapp.axl_rentals_f3b7283f1ce7.twa;



public class DelegationService extends
        com.google.androidbrowserhelper.trusted.DelegationService {
    @Override
    public void onCreate() {
        super.onCreate();

        
    }
}

